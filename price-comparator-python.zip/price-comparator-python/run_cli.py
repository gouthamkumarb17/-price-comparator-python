#!/usr/bin/env python3
"""Launch the terminal version: python run_cli.py"""
import argparse
import os
import sys
from pathlib import Path

from pricecomp.cli import CliApp
from pricecomp.storage import PriceStore


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(description="Product Price Comparator (terminal)")
    parser.add_argument("--data", default=str(Path(__file__).parent / "data" / "prices.json"), help="JSON data file")
    parser.add_argument("--no-color", action="store_true", help="turn off ANSI colours")
    args = parser.parse_args(argv)
    color = sys.stdout.isatty() and not args.no_color and "NO_COLOR" not in os.environ
    CliApp(PriceStore(args.data), color=color).run()


if __name__ == "__main__":
    main()
