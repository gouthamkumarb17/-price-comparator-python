"""JSON persistence with schema checks, corruption recovery and atomic writes."""
from __future__ import annotations

import contextlib
import json
import os
import tempfile
from dataclasses import replace
from datetime import date
from pathlib import Path
from typing import Iterable, Mapping

from .models import PriceRecord
from .seed import sample_records
from .validation import ValidationError, validate_record

SCHEMA_VERSION = 1


def _as_int(value) -> int:
    return value if isinstance(value, int) and not isinstance(value, bool) else 0


class PriceStore:
    """Holds all records in memory and mirrors them to a JSON file after every change."""

    def __init__(self, path, *, seed_if_missing: bool = True, today: date | None = None):
        self.path = Path(path)
        self._seed_if_missing = seed_if_missing
        self._today = today
        self._records: list[PriceRecord] = []
        self.notices: list[str] = []
        self.load()

    @property
    def records(self) -> list[PriceRecord]:
        return list(self._records)

    # ---- loading -------------------------------------------------------
    def load(self) -> None:
        self.notices = []
        if not self.path.exists():
            self._records = sample_records(self._today) if self._seed_if_missing else []
            self.save()
            suffix = " with sample data." if self._seed_if_missing else "."
            self.notices.append(f"No data file was found, so a new one was created at {self.path}{suffix}")
            return
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
            items = payload["records"] if isinstance(payload, dict) else payload
            if not isinstance(items, list):
                raise ValueError("'records' must be a list")
        except (OSError, ValueError, KeyError, TypeError) as exc:  # JSONDecodeError and UnicodeDecodeError are ValueErrors
            self._recover(exc)
            return
        loaded, dropped = [], 0
        for item in items:
            if not isinstance(item, dict):
                dropped += 1
                continue
            record, errors = validate_record(item, self._today, _as_int(item.get("id")))
            if errors:
                dropped += 1
            else:
                loaded.append(record)
        self._records = self._renumber(loaded)
        if dropped:
            self.notices.append(f"{dropped} invalid record(s) in the data file were skipped.")

    def _recover(self, exc: Exception) -> None:
        backup = self.path.with_name(f"{self.path.stem}.corrupt{self.path.suffix}")
        with contextlib.suppress(OSError):
            os.replace(self.path, backup)
        self._records = []
        self.save()
        self.notices.append(
            f"The data file could not be read ({exc}). The damaged file was kept as {backup.name} and a clean one was created."
        )

    @staticmethod
    def _renumber(records: list[PriceRecord]) -> list[PriceRecord]:
        used: set[int] = set()
        next_id = max((r.id for r in records), default=0) + 1
        fixed = []
        for r in records:
            if r.id <= 0 or r.id in used:
                r = replace(r, id=next_id)
                next_id += 1
            used.add(r.id)
            fixed.append(r)
        return fixed

    # ---- saving --------------------------------------------------------
    def save(self) -> None:
        """Write to a temp file, then swap it in, so a crash never leaves half a file."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"schema_version": SCHEMA_VERSION, "records": [r.to_dict() for r in self._records]}
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=self.path.name + ".", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, ensure_ascii=False)
            os.replace(tmp, self.path)
        except BaseException:
            with contextlib.suppress(OSError):
                os.unlink(tmp)
            raise

    # ---- changes -------------------------------------------------------
    def next_id(self) -> int:
        return max((r.id for r in self._records), default=0) + 1

    def add(self, raw: Mapping, today: date | None = None) -> PriceRecord:
        record, errors = validate_record(raw, today or self._today)
        if errors:
            raise ValidationError(errors)
        record = replace(record, id=self.next_id())
        self._records.append(record)
        self.save()
        return record

    def add_records(self, records: Iterable[PriceRecord]) -> list[PriceRecord]:
        added = []
        for r in records:
            added.append(replace(r, id=self.next_id()))
            self._records.append(added[-1])
        self.save()
        return added

    def delete(self, record_id: int) -> bool:
        kept = [r for r in self._records if r.id != record_id]
        changed = len(kept) != len(self._records)
        if changed:
            self._records = kept
            self.save()
        return changed

    def replace_all(self, records: Iterable[PriceRecord]) -> None:
        self._records = self._renumber(list(records))
        self.save()
