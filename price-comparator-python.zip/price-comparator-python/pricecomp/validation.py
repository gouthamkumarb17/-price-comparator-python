"""Defensive input validation. Every parser raises ValueError with a message safe to show users."""
from __future__ import annotations

import math
import re
from datetime import date
from typing import Mapping

from .models import CATEGORIES, MAX_PRICE, PriceRecord

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class ValidationError(ValueError):
    """Raised when a record fails validation. `errors` maps field name to message."""

    def __init__(self, errors: Mapping[str, str]):
        self.errors = dict(errors)
        super().__init__("; ".join(f"{k}: {v}" for k, v in self.errors.items()))


def clean_text(value) -> str:
    return " ".join(str(value if value is not None else "").split())


def parse_product(value) -> str:
    text = clean_text(value)
    if not 2 <= len(text) <= 60:
        raise ValueError("Enter a product name of 2-60 characters.")
    return text


def parse_store(value) -> str:
    text = clean_text(value)
    if not 2 <= len(text) <= 40:
        raise ValueError("Enter a store name of 2-40 characters.")
    return text


def parse_category(value) -> str:
    text = clean_text(value)
    for category in CATEGORIES:
        if category.casefold() == text.casefold():
            return category
    raise ValueError("Category must be one of: " + ", ".join(CATEGORIES) + ".")


def parse_price(value) -> float:
    text = str(value if value is not None else "").replace("\u20b9", "").replace(",", "").strip()
    if not text:
        raise ValueError("Price is required.")
    try:
        number = float(text)
    except ValueError:
        raise ValueError("Price must be a number, like 249.50.") from None
    if not math.isfinite(number):
        raise ValueError("Price must be a real number.")
    number = round(number, 2)
    if number <= 0:
        raise ValueError("Price must be at least 0.01.")
    if number > MAX_PRICE:
        raise ValueError("Price cannot be more than 10,00,000.")
    return number


def parse_date(value, today: date | None = None) -> str:
    today = today or date.today()
    text = str(value if value is not None else "").strip()
    if not _DATE_RE.match(text):
        raise ValueError("Use a date in YYYY-MM-DD format.")
    try:
        parsed = date.fromisoformat(text)
    except ValueError:
        raise ValueError("That is not a real calendar date.") from None
    if parsed > today:
        raise ValueError("Date cannot be in the future.")
    return parsed.isoformat()


def validate_record(raw: Mapping, today: date | None = None, record_id: int = 0):
    """Return (PriceRecord, {}) when valid, otherwise (None, {field: message})."""
    errors: dict[str, str] = {}
    values = {}
    parsers = {
        "product": parse_product,
        "category": parse_category,
        "store": parse_store,
        "price": parse_price,
        "date": lambda v: parse_date(v, today),
    }
    for field, parser in parsers.items():
        try:
            values[field] = parser(raw.get(field))
        except ValueError as exc:
            errors[field] = str(exc)
    if errors:
        return None, errors
    return PriceRecord(record_id, **values), {}
