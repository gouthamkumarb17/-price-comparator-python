import unittest
from datetime import date

from pricecomp.validation import parse_category, parse_date, parse_price, parse_product, parse_store, validate_record

TODAY = date(2026, 11, 24)


class PriceParsing(unittest.TestCase):
    def test_accepts_common_formats(self):
        self.assertEqual(parse_price("249.5"), 249.5)
        self.assertEqual(parse_price(" \u20b91,249.50 "), 1249.5)
        self.assertEqual(parse_price(100), 100.0)
        self.assertEqual(parse_price("0.01"), 0.01)
        self.assertEqual(parse_price("1000000"), 1_000_000.0)

    def test_rounds_to_paise(self):
        self.assertEqual(parse_price("10.456"), 10.46)

    def test_rejects_bad_values(self):
        for bad in ["", "   ", None, "abc", "12abc", "nan", "inf", "-inf", "0", "-5", "0.001", "1000000.01", "1e12"]:
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    parse_price(bad)


class DateParsing(unittest.TestCase):
    def test_valid_and_today(self):
        self.assertEqual(parse_date("2026-11-24", TODAY), "2026-11-24")
        self.assertEqual(parse_date(" 2026-01-05 ", TODAY), "2026-01-05")

    def test_rejects_bad_dates(self):
        for bad in ["", None, "24-11-2026", "2026/11/24", "2026-02-30", "2026-13-01", "2026-11-25", "yesterday"]:
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    parse_date(bad, TODAY)


class TextParsing(unittest.TestCase):
    def test_names_are_trimmed_and_collapsed(self):
        self.assertEqual(parse_product("  Basmati   Rice  "), "Basmati Rice")
        self.assertEqual(parse_store("Metro\tMart"), "Metro Mart")

    def test_length_limits(self):
        for fn, limit in ((parse_product, 60), (parse_store, 40)):
            with self.assertRaises(ValueError):
                fn("a")
            with self.assertRaises(ValueError):
                fn("")
            with self.assertRaises(ValueError):
                fn("x" * (limit + 1))
            self.assertEqual(fn("x" * limit), "x" * limit)

    def test_category_is_case_insensitive(self):
        self.assertEqual(parse_category(" groceries "), "Groceries")
        with self.assertRaises(ValueError):
            parse_category("Gadgets")


class WholeRecord(unittest.TestCase):
    good = {"product": "Rice", "category": "groceries", "store": "Metro Mart", "price": "99.5", "date": "2026-11-01"}

    def test_valid_record(self):
        record, errors = validate_record(self.good, TODAY, record_id=7)
        self.assertEqual(errors, {})
        self.assertEqual((record.id, record.category, record.price), (7, "Groceries", 99.5))

    def test_reports_every_bad_field_at_once(self):
        bad = {"product": "", "category": "x", "store": "", "price": "free", "date": "nope"}
        record, errors = validate_record(bad, TODAY)
        self.assertIsNone(record)
        self.assertEqual(set(errors), {"product", "category", "store", "price", "date"})

    def test_missing_fields(self):
        _, errors = validate_record({}, TODAY)
        self.assertEqual(len(errors), 5)


if __name__ == "__main__":
    unittest.main()
