# Product Price Comparator (Python)

Compare manually entered prices for the same product across stores, find the cheapest store, and see summaries, trends and warnings. Python 3.10+.

Two front ends share one tested core:

- **Streamlit web app** for the easy demo: `streamlit run streamlit_app.py`
- **Terminal menu** (the brief's must-have): `python run_cli.py`

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt    # only the Streamlit app needs this
streamlit run streamlit_app.py     # web demo
python run_cli.py                  # terminal demo (standard library only)
```

First launch creates `data/prices.json` and fills it with 38 sample records. Delete that file to start over.

## Tests

```bash
python -m unittest discover -s tests -t . -v     # no installs needed
pytest                                            # also works if you have pytest
```

The suite covers validation, comparison logic, outlier and stale detection, storage and corruption recovery, CSV import, report formats, the full terminal flow with scripted input, and a smoke test of every Streamlit page (runs when Streamlit is installed).

## Brief checklist

| Requirement | Where |
|---|---|
| Menu-driven terminal interface | `pricecomp/cli.py`, `run_cli.py` |
| Defensive input validation | `pricecomp/validation.py`; prompts loop until valid; `cancel` backs out |
| Comparison engine | `pricecomp/analysis.py` (`compare_products`, `latest_prices`) |
| JSON persistence, survives restarts | `pricecomp/storage.py` (atomic writes, corrupt file backed up and replaced) |
| Search by keyword and category | `search_records`, CLI option 3, Streamlit "Records" |
| Executive summary | `summarize`: totals, averages, best store, trends |
| Export CSV, Markdown, text log | `pricecomp/reports.py` |
| Threshold warnings | Outlier prices (median based) and prices older than 45 days |
| Bulk CSV import with error log | `pricecomp/csv_io.py`; try `data/sample_import_with_errors.csv` |
| Optional GUI | Streamlit app |
| 30-50 sample entries | `pricecomp/seed.py`, also `data/sample_prices.csv` and `.json` |

## Architecture

```
pricecomp/
  models.py      PriceRecord dataclass, categories
  validation.py  parsers that raise ValueError with user-safe messages
  analysis.py    pure functions: compare, outliers, stale, trends, summary
  storage.py     PriceStore: JSON file, schema checks, recovery
  csv_io.py      CSV parsing with per-row errors
  reports.py     CSV, Markdown and text exports
  formatting.py  rupee formatting (Indian digit grouping), text tables
  seed.py        sample data
  cli.py         terminal UI (input and output are injectable for tests)
streamlit_app.py web UI, a thin layer over the same functions
```

Nothing in `pricecomp/` imports a UI library, so the core can sit behind NiceGUI or FastHTML as easily as Streamlit.

## Suggested demo (about 4 minutes)

1. Launch the app. Open **Compare** and show the cheapest store per product.
2. **Add price**: leave Store blank and type `free` as the price. Show the errors. Then enter a valid price and watch the comparison update.
3. **Summary**: totals, wins by store, price history chart, and the two warnings (an unusual price and an old price).
4. **Import & export**: import `data/sample_import_with_errors.csv` and show the row-by-row error log. Download the Markdown report.
5. Close the app and relaunch it. The records are still there.

## Notes

- Prices are in rupees and rounded to two decimals.
- Product and store names match regardless of capital letters.
- A price counts as unusual when it is more than 2x above or below the product's median and there are at least 4 records for that product.
