"""Data model shared by every layer."""
from __future__ import annotations

from dataclasses import asdict, dataclass

CATEGORIES = ("Groceries", "Electronics", "Stationery", "Household", "Other")
MAX_PRICE = 1_000_000.0


@dataclass(frozen=True)
class PriceRecord:
    """One price seen for one product, in one store, on one day."""

    id: int
    product: str
    category: str
    store: str
    price: float
    date: str  # ISO format, YYYY-MM-DD

    @property
    def product_key(self) -> str:
        return self.product.casefold()

    @property
    def store_key(self) -> str:
        return self.store.casefold()

    def to_dict(self) -> dict:
        return asdict(self)
