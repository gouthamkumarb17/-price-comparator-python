"""Export formats: CSV data, Markdown report, plain-text audit log."""
from __future__ import annotations

import csv
import io
from datetime import date
from typing import Iterable, Mapping

from .analysis import Summary
from .csv_io import FIELDS
from .formatting import format_inr
from .models import PriceRecord


def to_csv(records: Iterable[PriceRecord]) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\n")
    writer.writerow(FIELDS)
    for r in sorted(records, key=lambda r: (r.date, r.id)):
        writer.writerow([r.product, r.category, r.store, f"{r.price:.2f}", r.date])
    return buffer.getvalue()


def _cell(text: str) -> str:
    return text.replace("|", "\\|")


def to_markdown(summary: Summary, today: date | None = None) -> str:
    today = today or date.today()
    by_id = {r.id: r for r in summary.records}
    lines = [
        "# Price comparison report",
        "",
        f"Generated {today.isoformat()}. {summary.record_count} records, "
        f"{summary.product_count} products, {summary.store_count} stores.",
        "",
        "## Cheapest store per product",
        "",
        "| Product | Cheapest store | Lowest | Highest | Saving |",
        "|---|---|---|---|---|",
    ]
    for c in summary.comparisons:
        if c.has_choice:
            lines.append(
                f"| {_cell(c.product)} | {_cell(c.cheapest_store)} | {format_inr(c.lowest.price)} | "
                f"{format_inr(c.highest.price)} | {format_inr(c.savings)} ({c.savings_pct:.1f}%) |"
            )
        else:
            lines.append(f"| {_cell(c.product)} | only {_cell(c.lowest.store)} | {format_inr(c.lowest.price)} | n/a | n/a |")
    lines += ["", "## Cheapest-price wins by store", ""]
    lines += [f"- {s}: {n}" for s, n in sorted(summary.store_wins.items(), key=lambda kv: -kv[1])] or ["- None yet"]
    lines += ["", "## Warnings", ""]
    warnings = [
        f"- Check price: {by_id[i].product} at {by_id[i].store}, {format_inr(by_id[i].price)} on {by_id[i].date}. {why}."
        for i, why in summary.outliers.items()
    ] + [f"- Old price: {r.product} at {r.store} was last updated on {r.date}." for r in summary.stale]
    lines += warnings or ["- None"]
    return "\n".join(lines) + "\n"


def to_text_log(records: Iterable[PriceRecord], outliers: Mapping[int, str] | None = None, today: date | None = None) -> str:
    today = today or date.today()
    outliers = outliers or {}
    lines = [f"PRICE AUDIT LOG {today.isoformat()}"]
    for r in sorted(records, key=lambda r: (r.date, r.id)):
        flag = "  [CHECK PRICE]" if r.id in outliers else ""
        lines.append(f"{r.date}  #{r.id}  {r.product} | {r.category} | {r.store} | {format_inr(r.price)}{flag}")
    return "\n".join(lines) + "\n"
