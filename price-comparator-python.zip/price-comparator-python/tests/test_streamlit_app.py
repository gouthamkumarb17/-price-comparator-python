"""Smoke test for the Streamlit UI. Skipped automatically when streamlit is not installed."""
import importlib.util
import os
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PAGES = ["Compare", "Add price", "Records", "Summary", "Import & export"]


@unittest.skipUnless(importlib.util.find_spec("streamlit"), "streamlit is not installed")
class StreamlitSmoke(unittest.TestCase):
    def test_every_page_renders_without_errors(self):
        from streamlit.testing.v1 import AppTest

        with tempfile.TemporaryDirectory() as tmp:
            os.environ["PRICECOMP_DATA"] = str(Path(tmp) / "prices.json")
            self.addCleanup(os.environ.pop, "PRICECOMP_DATA", None)
            app = AppTest.from_file(str(ROOT / "streamlit_app.py"), default_timeout=30).run()
            self.assertFalse(app.exception)
            for page in PAGES:
                app.sidebar.radio[0].set_value(page).run()
                self.assertFalse(app.exception, page)


if __name__ == "__main__":
    unittest.main()
