import unittest
from datetime import date
from pathlib import Path

from pricecomp.analysis import find_outliers, summarize
from pricecomp.csv_io import parse_csv
from pricecomp.formatting import format_inr, render_table
from pricecomp.reports import to_csv, to_markdown, to_text_log
from pricecomp.seed import sample_records
from tests.helpers import rec

TODAY = date(2026, 11, 24)
HEADER = "product,category,store,price,date\n"
ROOT = Path(__file__).resolve().parent.parent


class CsvImport(unittest.TestCase):
    def test_good_file(self):
        r = parse_csv(HEADER + "Tea,Groceries,Metro,185,2026-11-20\nCable,electronics,Daily,299.5,2026-11-21\n", TODAY)
        self.assertEqual((len(r.records), r.errors, r.total_rows), (2, [], 2))
        self.assertEqual(r.records[1].category, "Electronics")

    def test_header_order_is_flexible_and_bom_ok(self):
        r = parse_csv("\ufeffdate,price,store,category,product\n2026-11-20,185,Metro,Groceries,Tea\n", TODAY)
        self.assertEqual((r.records[0].product, r.records[0].price), ("Tea", 185.0))

    def test_headerless_file(self):
        r = parse_csv("Tea,Groceries,Metro,185,2026-11-20\n", TODAY)
        self.assertEqual(len(r.records), 1)

    def test_quoted_commas(self):
        r = parse_csv(HEADER + '"Tea, green",Groceries,Metro,"1,185.50",2026-11-20\n', TODAY)
        self.assertEqual((r.records[0].product, r.records[0].price), ("Tea, green", 1185.5))

    def test_bad_rows_are_logged_with_row_numbers(self):
        text = HEADER + "Tea,Groceries,Metro,185,2026-11-20\nTea,Groceries,Daily,free,2026-11-20\nA,Groceries,Daily,5,2026-11-20\nTea,Groceries,Daily,5\n"
        r = parse_csv(text, TODAY)
        self.assertEqual(len(r.records), 1)
        self.assertEqual([e.row for e in r.errors], [3, 4, 5])
        self.assertIn("number", r.errors[0].message)
        self.assertIn("product", r.errors[1].message.lower())

    def test_missing_header_column_stops_cleanly(self):
        r = parse_csv("product,price\nTea,5\n", TODAY)
        self.assertEqual(r.records, [])
        self.assertIn("missing", r.errors[0].message.lower())

    def test_empty_file(self):
        self.assertTrue(parse_csv("", TODAY).errors)
        self.assertTrue(parse_csv("\n\n  \n", TODAY).errors)

    def test_duplicates_in_file_and_against_existing(self):
        existing = [rec(1, "Tea", "Metro", 185.0, "2026-11-20")]
        text = HEADER + "Tea,Groceries,Metro,185,2026-11-20\nTea,Groceries,Daily,170,2026-11-20\nTea,Groceries,Daily,170,2026-11-20\n"
        r = parse_csv(text, TODAY, existing=existing)
        self.assertEqual(len(r.records), 1)
        self.assertEqual([e.row for e in r.errors], [2, 4])

    def test_shipped_demo_file_shows_a_mix_of_results(self):
        r = parse_csv((ROOT / "data" / "sample_import_with_errors.csv").read_text(encoding="utf-8"), TODAY)
        self.assertGreaterEqual(len(r.records), 5)
        self.assertGreaterEqual(len(r.errors), 5)

    def test_shipped_sample_csv_imports_cleanly(self):
        r = parse_csv((ROOT / "data" / "sample_prices.csv").read_text(encoding="utf-8"), TODAY)
        self.assertEqual((len(r.records), r.errors), (38, []))


class Formatting(unittest.TestCase):
    def test_indian_grouping(self):
        cases = {0.5: "\u20b90.50", 100: "\u20b9100.00", 999.999: "\u20b91,000.00", 1234.5: "\u20b91,234.50",
                 99999: "\u20b999,999.00", 100000: "\u20b91,00,000.00", 1234567.891: "\u20b912,34,567.89", -2500: "-\u20b92,500.00"}
        for value, expected in cases.items():
            self.assertEqual(format_inr(value), expected)

    def test_table_alignment(self):
        out = render_table(("A", "B"), [("x", 1), ("long", 22)], "lr").splitlines()
        self.assertEqual(len(out), 4)
        self.assertEqual(len({len(line) for line in out[:1] + out[2:]}), 1)
        self.assertEqual(render_table(("A",), []).splitlines()[0], "A")


class Reports(unittest.TestCase):
    def setUp(self):
        self.records = sample_records(TODAY)

    def test_csv_round_trips(self):
        back = parse_csv(to_csv(self.records), TODAY)
        self.assertEqual(back.errors, [])
        expected = [(r.product, r.store, r.price, r.date) for r in sorted(self.records, key=lambda r: (r.date, r.id))]
        self.assertEqual([(r.product, r.store, r.price, r.date) for r in back.records], expected)

    def test_markdown_report(self):
        md = to_markdown(summarize(self.records, TODAY), TODAY)
        for needle in ("# Price comparison report", "## Cheapest store per product", "Daily Basket", "## Warnings", "Check price", "Old price"):
            self.assertIn(needle, md)

    def test_markdown_escapes_pipes(self):
        md = to_markdown(summarize([rec(1, "A|B", "S1", 5), rec(2, "A|B", "S2", 6)], TODAY), TODAY)
        self.assertIn("A\\|B", md)

    def test_text_log_flags_outliers(self):
        log = to_text_log(self.records, find_outliers(self.records), TODAY)
        self.assertEqual(log.count("[CHECK PRICE]"), 1)
        self.assertEqual(len(log.splitlines()), 39)


if __name__ == "__main__":
    unittest.main()
