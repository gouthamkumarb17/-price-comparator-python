"""Product Price Comparator: framework-free core used by the CLI and the Streamlit app."""

__version__ = "1.0.0"
