"""Streamlit front end for the demo. Run: streamlit run streamlit_app.py"""
from __future__ import annotations

import os
from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

from pricecomp.analysis import compare_products, find_outliers, search_records, sort_records, summarize
from pricecomp.csv_io import TEMPLATE, parse_csv
from pricecomp.formatting import format_inr
from pricecomp.models import CATEGORIES
from pricecomp.reports import to_csv, to_markdown, to_text_log
from pricecomp.seed import sample_records
from pricecomp.storage import PriceStore
from pricecomp.validation import ValidationError

DATA_PATH = Path(os.environ.get("PRICECOMP_DATA", Path(__file__).parent / "data" / "prices.json"))
PAGES = ["Compare", "Add price", "Records", "Summary", "Import & export"]

st.set_page_config(page_title="Product Price Comparator", page_icon="🏷️", layout="wide")
store = PriceStore(DATA_PATH)


def flash(message: str, kind: str = "success") -> None:
    """Show a message after the page reloads with fresh data."""
    st.session_state["flash"] = (kind, message)
    st.rerun()


def page_compare() -> None:
    comparisons = compare_products(store.records)
    if not comparisons:
        st.info("No prices yet. Open “Add price” to enter your first one.")
        return
    choice = st.selectbox("Product", ["All products"] + [c.product for c in comparisons])
    for c in comparisons:
        if choice != "All products" and c.product != choice:
            continue
        with st.container(border=True):
            st.subheader(c.product)
            st.caption(c.category)
            if c.has_choice:
                st.success(
                    f"Cheapest at {c.cheapest_store}: save {format_inr(c.savings)} "
                    f"({c.savings_pct:.1f}%) compared with {c.highest.store}."
                )
            else:
                st.info("Only one store so far. Add another store's price to compare.")
            for start in range(0, len(c.offers), 4):
                chunk = c.offers[start : start + 4]
                for position, (column, offer) in enumerate(zip(st.columns(len(chunk)), chunk)):
                    is_lowest = c.has_choice and start + position == 0
                    if c.has_choice and not is_lowest:
                        column.metric(offer.store, format_inr(offer.price), f"+{format_inr(c.gap(offer))}", delta_color="inverse")
                    else:
                        column.metric(offer.store, format_inr(offer.price))
                    if is_lowest:
                        column.markdown(":green[**Lowest price**]")
                    column.caption(f"Seen {offer.date}")


def page_add() -> None:
    with st.form("add_price"):
        left, right = st.columns(2)
        product = left.text_input("Product")
        category = right.selectbox("Category", CATEGORIES)
        a, b, c = st.columns(3)
        shop = a.text_input("Store")
        price = b.text_input("Price (₹)", placeholder="249.50")
        seen = c.date_input("Date seen", value=date.today(), max_value=date.today())
        submitted = st.form_submit_button("Save price", type="primary")
    if not submitted:
        return
    try:
        record = store.add({"product": product, "category": category, "store": shop, "price": price, "date": seen.isoformat()})
    except ValidationError as exc:
        for field, message in exc.errors.items():
            st.error(f"{field.title()}: {message}")
        return
    message = f"Saved {record.product} at {record.store} for {format_inr(record.price)}."
    match = next((x for x in compare_products(store.records) if x.product_key == record.product_key), None)
    if match and match.has_choice:
        message += f" Cheapest now: {match.cheapest_store} ({format_inr(match.lowest.price)})."
    flash(message)


def page_records() -> None:
    records = store.records
    flagged = find_outliers(records)
    c1, c2, c3 = st.columns([2, 1, 1])
    query = c1.text_input("Search", placeholder="Product, store or category")
    category = c2.selectbox("Category", ["All"] + list(CATEGORIES))
    order = c3.selectbox("Sort by", ["date", "price", "product", "store"])
    shown = sort_records(search_records(records, query, None if category == "All" else category), order)
    st.caption(f"{len(shown)} of {len(records)} records")
    if not shown:
        st.info("Nothing matches. Clear the search or pick another category.")
        return
    frame = pd.DataFrame(
        [
            {"ID": r.id, "Product": r.product, "Category": r.category, "Store": r.store, "Price (₹)": r.price,
             "Date": r.date, "Status": "Check price" if r.id in flagged else ""}
            for r in shown
        ]
    )
    st.dataframe(frame, hide_index=True)
    with st.expander("Delete a record"):
        labels = {r.id: f"#{r.id} {r.product} at {r.store}, {format_inr(r.price)} ({r.date})" for r in shown}
        target = st.selectbox("Record", list(labels), format_func=labels.get)
        if st.button("Delete selected record"):
            store.delete(target)
            flash("Record deleted.")


def page_summary() -> None:
    s = summarize(store.records)
    if not s.record_count:
        st.info("No records yet.")
        return
    cols = st.columns(5)
    cols[0].metric("Records", s.record_count)
    cols[1].metric("Products", s.product_count)
    cols[2].metric("Stores", s.store_count)
    cols[3].metric("Average price", format_inr(s.average_price))
    cols[4].metric("Average saving", f"{s.average_saving_pct:.1f}%")
    if s.best_store:
        st.success(f"Best store overall: {s.best_store}")
    if s.store_wins:
        st.subheader("Cheapest-price wins by store")
        st.bar_chart(pd.DataFrame({"Wins": s.store_wins}))
    st.subheader("By product")
    rows = []
    for c in s.comparisons:
        prices = [o.price for o in c.offers]
        trend = s.trends.get(c.product)
        rows.append({
            "Product": c.product,
            "Cheapest store": c.cheapest_store if c.has_choice else "-",
            "Lowest (₹)": min(prices),
            "Highest (₹)": max(prices),
            "Average (₹)": round(sum(prices) / len(prices), 2),
            "Trend (%)": None if trend is None else round(trend, 1),
        })
    st.dataframe(pd.DataFrame(rows), hide_index=True)
    st.subheader("Price history")
    name = st.selectbox("Product", [c.product for c in s.comparisons], key="history_product")
    history = [r for r in s.records if r.product.casefold() == name.casefold()]
    frame = pd.DataFrame({"Date": pd.to_datetime([r.date for r in history]), "Store": [r.store for r in history], "Price": [r.price for r in history]})
    st.line_chart(frame.pivot_table(index="Date", columns="Store", values="Price", aggfunc="last").sort_index().ffill())
    st.subheader("Warnings")
    by_id = {r.id: r for r in s.records}
    for record_id, why in s.outliers.items():
        r = by_id[record_id]
        st.warning(f"{r.product} at {r.store} is {format_inr(r.price)} on {r.date}. {why}.")
    for r in s.stale:
        st.warning(f"{r.product} at {r.store} has not been updated since {r.date}.")
    if not s.outliers and not s.stale:
        st.success("No unusual or outdated prices.")


def page_io() -> None:
    st.subheader("Import prices from CSV")
    st.caption("Columns: product, category, store, price, date (YYYY-MM-DD). Bad rows are skipped and listed below.")
    st.download_button("Download blank template", TEMPLATE, file_name="price_template.csv", mime="text/csv")
    upload = st.file_uploader("CSV file", type=["csv"])
    pasted = st.text_area("Or paste CSV rows", height=120)
    if st.button("Import rows"):
        text = upload.getvalue().decode("utf-8-sig", errors="replace") if upload else pasted
        if not text.strip():
            st.warning("Choose a file or paste some rows first.")
        else:
            result = parse_csv(text, existing=store.records)
            store.add_records(result.records)
            (st.success if not result.errors else st.warning)(result.describe())
            if result.errors:
                st.dataframe(pd.DataFrame([{"Row": e.row, "Problem": e.message} for e in result.errors]), hide_index=True)
    st.subheader("Export a report")
    kind = st.selectbox("Format", ["CSV data", "Markdown report", "Plain-text audit log"])
    records = store.records
    if kind == "CSV data":
        text, name, mime = to_csv(records), "prices.csv", "text/csv"
    elif kind == "Markdown report":
        text, name, mime = to_markdown(summarize(records)), "price_report.md", "text/markdown"
    else:
        text, name, mime = to_text_log(records, find_outliers(records)), "price_audit_log.txt", "text/plain"
    st.download_button(f"Download {name}", text, file_name=name, mime=mime)
    st.code(text[:4000], language=None)
    st.subheader("Reset data")
    sure = st.checkbox("I understand this replaces my current records")
    left, right = st.columns(2)
    if left.button("Load sample data", disabled=not sure):
        store.replace_all(sample_records())
        flash("Sample data loaded.")
    if right.button("Delete all records", disabled=not sure):
        store.replace_all([])
        flash("All records deleted.", "warning")


st.title("🏷️ Product Price Comparator")
st.sidebar.header("Menu")
page = st.sidebar.radio("Go to", PAGES, key="page", label_visibility="collapsed")
st.sidebar.caption(f"Data file: {DATA_PATH.name}")
for notice in store.notices:
    st.info(notice)
if "flash" in st.session_state:
    kind, text = st.session_state.pop("flash")
    getattr(st, kind)(text)
{"Compare": page_compare, "Add price": page_add, "Records": page_records, "Summary": page_summary, "Import & export": page_io}[page]()
