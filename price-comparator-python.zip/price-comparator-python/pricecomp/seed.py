"""Realistic sample data: 38 records with normal, boundary and edge cases."""
from __future__ import annotations

from datetime import date, timedelta

from .models import PriceRecord

STORES = ("Metro Mart", "Daily Basket", "Online Bazaar")
_PRODUCTS = (
    ("Basmati Rice 5 kg", "Groceries", 620.0, (1.00, 0.94, 1.06)),
    ("Toor Dal 1 kg", "Groceries", 165.0, (1.00, 1.05, 0.93)),
    ("Sunflower Oil 1 L", "Groceries", 150.0, (0.97, 1.00, 1.08)),
    ("Wireless Mouse", "Electronics", 799.0, (1.04, 1.00, 0.90)),
    ("USB-C Cable 1 m", "Electronics", 349.0, (1.00, 0.88, 1.10)),
    ("A4 Notebook (200 pages)", "Stationery", 120.0, (1.05, 0.94, 1.00)),
)


def sample_records(today: date | None = None) -> list[PriceRecord]:
    today = today or date.today()

    def ago(days: int) -> str:
        return (today - timedelta(days=days)).isoformat()

    records: list[PriceRecord] = []

    def add(product, category, store, price, age):
        records.append(PriceRecord(len(records) + 1, product, category, store, round(price, 2), ago(age)))

    for name, category, base, factors in _PRODUCTS:
        for store, factor in zip(STORES, factors):
            for age, drift in ((60, 0.96), (7, 1.0)):
                add(name, category, store, base * factor * drift, age)
    add("Wireless Mouse", "Electronics", "Daily Basket", 79.9, 30)  # likely typo: unusual price
    add("Cloth Carry Bag", "Household", "Metro Mart", 0.5, 50)  # boundary price and a stale entry
    return records
