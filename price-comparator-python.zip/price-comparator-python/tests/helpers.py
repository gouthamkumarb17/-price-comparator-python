from pricecomp.models import PriceRecord

TODAY_ISO = "2026-11-24"


def rec(id, product, store, price, date="2026-11-20", category="Groceries"):
    return PriceRecord(id, product, category, store, price, date)
