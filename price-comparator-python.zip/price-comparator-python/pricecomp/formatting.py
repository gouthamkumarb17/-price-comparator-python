"""Presentation helpers with no knowledge of storage or analysis."""
from __future__ import annotations


def format_inr(amount: float) -> str:
    """Format a number as rupees with Indian digit grouping, e.g. 1234567.5 -> ₹12,34,567.50."""
    sign = "-" if amount < 0 else ""
    whole, frac = f"{abs(amount):.2f}".split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        whole = ",".join(parts + [tail])
    return f"{sign}\u20b9{whole}.{frac}"


def render_table(headers, rows, aligns: str = "") -> str:
    """Fixed-width text table. `aligns` is one 'l' or 'r' per column."""
    cells = [[str(c) for c in row] for row in rows]
    aligns = aligns.ljust(len(headers), "l")
    widths = [max([len(str(h))] + [len(r[i]) for r in cells]) for i, h in enumerate(headers)]

    def line(items):
        return " | ".join(
            s.rjust(w) if a == "r" else s.ljust(w) for s, w, a in zip(items, widths, aligns)
        ).rstrip()

    rule = "-+-".join("-" * w for w in widths)
    return "\n".join([line([str(h) for h in headers]), rule] + [line(r) for r in cells])
