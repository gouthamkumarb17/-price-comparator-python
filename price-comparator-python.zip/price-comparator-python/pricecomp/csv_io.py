"""Bulk CSV import with automatic format validation and a row-by-row error log."""
from __future__ import annotations

import csv
import io
from dataclasses import dataclass, field
from datetime import date
from typing import Iterable

from .models import PriceRecord
from .validation import validate_record

FIELDS = ("product", "category", "store", "price", "date")
TEMPLATE = ",".join(FIELDS) + "\n"


@dataclass(frozen=True)
class RowError:
    row: int
    message: str


@dataclass
class ImportResult:
    records: list[PriceRecord] = field(default_factory=list)
    errors: list[RowError] = field(default_factory=list)
    total_rows: int = 0

    def describe(self) -> str:
        return f"{len(self.records)} imported, {len(self.errors)} skipped, out of {self.total_rows} rows."


def parse_csv(text: str, today: date | None = None, existing: Iterable[PriceRecord] = ()) -> ImportResult:
    """Validate every row. Valid rows are returned (ids unassigned); bad rows are logged, never fatal."""
    result = ImportResult()
    rows = [
        (number, row)
        for number, row in enumerate(csv.reader(io.StringIO(text.lstrip("\ufeff"))), start=1)
        if any(cell.strip() for cell in row)
    ]
    if not rows:
        result.errors.append(RowError(1, "The file is empty."))
        return result

    first_cells = [c.strip().casefold() for c in rows[0][1]]
    column_of: dict[str, int] | None = None
    if "product" in first_cells and "price" in first_cells:
        column_of = {name: i for i, name in enumerate(first_cells)}
        missing = [f for f in FIELDS if f not in column_of]
        if missing:
            result.errors.append(RowError(rows[0][0], "Header is missing column(s): " + ", ".join(missing) + "."))
            return result
        rows = rows[1:]

    seen = {(r.product_key, r.store_key, r.date, r.price) for r in existing}
    result.total_rows = len(rows)
    for number, row in rows:
        if column_of is None:
            if len(row) != len(FIELDS):
                result.errors.append(RowError(number, f"Expected {len(FIELDS)} columns but found {len(row)}."))
                continue
            raw = dict(zip(FIELDS, row))
        else:
            raw = {f: (row[column_of[f]] if column_of[f] < len(row) else "") for f in FIELDS}
        record, errors = validate_record(raw, today)
        if errors:
            result.errors.append(RowError(number, " ".join(errors.values())))
            continue
        key = (record.product_key, record.store_key, record.date, record.price)
        if key in seen:
            result.errors.append(RowError(number, "Duplicate of a record that already exists."))
            continue
        seen.add(key)
        result.records.append(record)
    return result
