import unittest
from datetime import date

from pricecomp.analysis import (compare_products, find_outliers, find_stale, latest_prices, price_trends,
                                search_records, sort_records, summarize)
from pricecomp.seed import sample_records
from tests.helpers import rec

TODAY = date(2026, 11, 24)


class Comparison(unittest.TestCase):
    def test_cheapest_first_with_savings(self):
        c = compare_products([rec(1, "Rice", "A", 120), rec(2, "Rice", "B", 100), rec(3, "Rice", "C", 110)])[0]
        self.assertEqual([o.store for o in c.offers], ["B", "C", "A"])
        self.assertEqual(c.cheapest_store, "B")
        self.assertEqual(c.savings, 20)
        self.assertAlmostEqual(c.savings_pct, 16.667, places=2)
        self.assertEqual(c.gap(c.offers[1]), 10)
        self.assertAlmostEqual(c.gap_pct(c.offers[1]), 10.0)

    def test_newest_price_per_store_wins_even_if_dearer(self):
        old, new = rec(1, "Rice", "A", 80, "2026-09-01"), rec(2, "Rice", "A", 130, "2026-11-01")
        self.assertEqual(latest_prices([old, new]), [new])
        self.assertEqual(latest_prices([new, old]), [new])

    def test_same_day_tie_uses_higher_id(self):
        a, b = rec(1, "Rice", "A", 80), rec(2, "Rice", "A", 90)
        self.assertEqual(latest_prices([a, b]), [b])

    def test_matching_ignores_case(self):
        comps = compare_products([rec(1, "Rice", "Metro", 100), rec(2, "rice", "METRO", 90, "2026-11-21"), rec(3, "RICE", "Other", 95)])
        self.assertEqual(len(comps), 1)
        self.assertEqual(len(comps[0].offers), 2)

    def test_single_store_has_no_choice(self):
        c = compare_products([rec(1, "Rice", "A", 100)])[0]
        self.assertFalse(c.has_choice)
        self.assertEqual(c.savings, 0)

    def test_empty(self):
        self.assertEqual(compare_products([]), [])

    def test_exclude_ids(self):
        comps = compare_products([rec(1, "Rice", "A", 100), rec(2, "Rice", "B", 1)], exclude_ids=[2])
        self.assertEqual(comps[0].cheapest_store, "A")


class Outliers(unittest.TestCase):
    def test_flags_far_prices(self):
        rows = [rec(1, "X", "A", 100), rec(2, "X", "B", 102), rec(3, "X", "C", 98), rec(4, "X", "D", 101), rec(5, "X", "E", 10), rec(6, "X", "F", 500)]
        self.assertEqual(set(find_outliers(rows)), {5, 6})

    def test_needs_enough_samples(self):
        rows = [rec(1, "X", "A", 100), rec(2, "X", "B", 100), rec(3, "X", "C", 10)]
        self.assertEqual(find_outliers(rows), {})

    def test_normal_spread_is_not_flagged(self):
        rows = [rec(i, "X", s, p) for i, (s, p) in enumerate([("A", 90), ("B", 100), ("C", 110), ("D", 120)], 1)]
        self.assertEqual(find_outliers(rows), {})


class StaleAndTrends(unittest.TestCase):
    def test_stale_uses_latest_per_store(self):
        rows = [rec(1, "X", "A", 10, "2026-09-01"), rec(2, "X", "A", 11, "2026-11-20"), rec(3, "X", "B", 12, "2026-09-01")]
        self.assertEqual([r.id for r in find_stale(rows, TODAY)], [3])

    def test_stale_boundary(self):
        self.assertEqual(find_stale([rec(1, "X", "A", 1, "2026-10-10")], TODAY), [])  # exactly 45 days
        self.assertEqual(len(find_stale([rec(1, "X", "A", 1, "2026-10-09")], TODAY)), 1)

    def test_trend_is_average_of_store_changes(self):
        rows = [rec(1, "X", "A", 100, "2026-10-01"), rec(2, "X", "A", 110, "2026-11-01"),
                rec(3, "X", "B", 200, "2026-10-01"), rec(4, "X", "B", 180, "2026-11-01")]
        self.assertAlmostEqual(price_trends(rows)["x"], 0.0)
        self.assertAlmostEqual(price_trends(rows[:2])["x"], 10.0)

    def test_trend_needs_two_points(self):
        self.assertEqual(price_trends([rec(1, "X", "A", 100)]), {})

    def test_trend_can_exclude_ids(self):
        rows = [rec(1, "X", "A", 100, "2026-10-01"), rec(2, "X", "A", 110, "2026-11-01")]
        self.assertEqual(price_trends(rows, exclude_ids=[2]), {})


class SearchAndSort(unittest.TestCase):
    rows = [rec(1, "Basmati Rice", "Metro", 100), rec(2, "USB Cable", "Daily", 300, "2026-11-22", "Electronics"), rec(3, "Dal", "Metro", 50, "2026-11-21")]

    def test_keyword_matches_product_store_or_category(self):
        self.assertEqual({r.id for r in search_records(self.rows, "metro")}, {1, 3})
        self.assertEqual({r.id for r in search_records(self.rows, "rice")}, {1})
        self.assertEqual({r.id for r in search_records(self.rows, "electronics")}, {2})

    def test_category_filter_and_blank(self):
        self.assertEqual({r.id for r in search_records(self.rows, "", "groceries")}, {1, 3})
        self.assertEqual(len(search_records(self.rows)), 3)
        self.assertEqual(search_records(self.rows, "zzz"), [])

    def test_sorting(self):
        self.assertEqual([r.id for r in sort_records(self.rows, "date")], [2, 3, 1])
        self.assertEqual([r.id for r in sort_records(self.rows, "price")], [3, 1, 2])
        self.assertEqual([r.id for r in sort_records(self.rows, "product")], [1, 3, 2])
        with self.assertRaises(ValueError):
            sort_records(self.rows, "colour")


class SummaryOnSampleData(unittest.TestCase):
    def setUp(self):
        self.records = sample_records(TODAY)
        self.s = summarize(self.records, TODAY)

    def test_counts(self):
        self.assertEqual((self.s.record_count, self.s.product_count, self.s.store_count), (38, 7, 3))

    def test_wins_and_best_store(self):
        self.assertEqual(self.s.store_wins, {"Daily Basket": 3, "Online Bazaar": 2, "Metro Mart": 1})
        self.assertEqual(self.s.best_store, "Daily Basket")

    def test_flags_the_planted_problems(self):
        typo = next(r for r in self.records if r.price == 79.9)
        self.assertEqual(set(self.s.outliers), {typo.id})
        self.assertEqual([r.product for r in self.s.stale], ["Cloth Carry Bag"])

    def test_outlier_does_not_distort_trends(self):
        self.assertTrue(all(-20 < t < 20 for t in self.s.trends.values()))
        self.assertGreater(self.s.average_saving_pct, 0)

    def test_empty_summary(self):
        s = summarize([], TODAY)
        self.assertEqual((s.record_count, s.average_price, s.best_store, s.store_wins), (0, 0.0, None, {}))

    def test_tied_wins_count_for_every_store(self):
        s = summarize([rec(1, "X", "A", 10), rec(2, "X", "B", 10)], TODAY)
        self.assertEqual(s.store_wins, {"A": 1, "B": 1})
        self.assertEqual(s.best_store, "A")


if __name__ == "__main__":
    unittest.main()
