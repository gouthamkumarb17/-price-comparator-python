import tempfile
import unittest
from datetime import date
from pathlib import Path

from pricecomp.cli import CliApp
from pricecomp.storage import PriceStore

TODAY = date(2026, 11, 24)
ROOT = Path(__file__).resolve().parent.parent


class CliTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.dir = Path(self._tmp.name)
        self.store = PriceStore(self.dir / "prices.json", today=TODAY)
        self.out = []

    def run_cli(self, answers):
        feed = iter(answers)

        def fake_input(prompt):
            try:
                return next(feed)
            except StopIteration:
                raise EOFError from None

        CliApp(self.store, fake_input, self.out.append, TODAY, export_dir=self.dir / "exports").run()
        return "\n".join(self.out)

    def test_bad_input_is_corrected_not_fatal(self):
        text = self.run_cli(["1", "", "Green Tea 100 g", "9", "bogus", "1", "Metro Mart", "abc", "-4", "185.50", "2099-01-01", "", "0"])
        for message in ("2-60 characters", "Choose a number", "Category must be one of", "must be a number", "at least 0.01", "future"):
            self.assertIn(message, text)
        saved = [r for r in self.store.records if r.product == "Green Tea 100 g"]
        self.assertEqual([(r.category, r.price, r.date) for r in saved], [("Groceries", 185.5, "2026-11-24")])
        self.assertIn("Goodbye", text)

    def test_cancel_returns_to_menu(self):
        before = len(self.store.records)
        text = self.run_cli(["1", "Tea", "cancel", "0"])
        self.assertIn("Cancelled.", text)
        self.assertEqual(len(self.store.records), before)

    def test_invalid_menu_choice(self):
        self.assertIn("not a valid option", self.run_cli(["x", "", "42", "0"]))

    def test_compare_filter(self):
        text = self.run_cli(["2", "rice", "0"])
        self.assertIn("Basmati Rice 5 kg", text)
        self.assertNotIn("USB-C", text)
        self.assertIn("Save", text)

    def test_compare_no_match(self):
        self.assertIn("No products match", self.run_cli(["2", "zzz", "0"]))

    def test_search_paginates(self):
        text = self.run_cli(["3", "", "", "", "0"])  # any keyword, any category, Enter for page 2 and page 3... then menu 0
        self.assertIn("Showing 1-10 of 38", text)
        self.assertIn("Showing 11-20 of 38", text)

    def test_search_can_stop_early_and_filter(self):
        text = self.run_cli(["3", "", "", "q", "0"])
        self.assertNotIn("Showing 11-20", text)
        text = self.run_cli(["3", "mouse", "electronics", "0"])
        self.assertIn("CHECK PRICE", text)

    def test_summary_shows_warnings(self):
        text = self.run_cli(["4", "0"])
        self.assertIn("Best store overall: Daily Basket", text)
        self.assertIn("WARNING  Wireless Mouse", text)
        self.assertIn("WARNING  Cloth Carry Bag", text)

    def test_import_logs_bad_rows(self):
        before = len(self.store.records)
        text = self.run_cli(["5", str(ROOT / "data" / "sample_import_with_errors.csv"), "0"])
        self.assertIn("imported", text)
        self.assertIn("row ", text)
        self.assertGreater(len(self.store.records), before)

    def test_import_missing_file(self):
        self.assertIn("Could not read", self.run_cli(["5", str(self.dir / "nope.csv"), "0"]))

    def test_export_writes_file(self):
        text = self.run_cli(["6", "pdf", "md", "0"])
        self.assertIn("Type csv, md or txt", text)
        report = self.dir / "exports" / "price_report_2026-11-24.md"
        self.assertIn("# Price comparison report", report.read_text(encoding="utf-8"))

    def test_load_sample_needs_confirmation(self):
        self.store.replace_all([])
        self.run_cli(["7", "", "0"])
        self.assertEqual(self.store.records, [])
        self.run_cli(["7", "yes", "0"])
        self.assertEqual(len(self.store.records), 38)

    def test_end_of_input_exits_cleanly(self):
        self.assertIn("Goodbye", self.run_cli([]))

    def test_changes_persist_after_restart(self):
        self.run_cli(["1", "Green Tea", "1", "Metro Mart", "185", "", "0"])
        again = PriceStore(self.dir / "prices.json", today=TODAY)
        self.assertTrue(any(r.product == "Green Tea" for r in again.records))


if __name__ == "__main__":
    unittest.main()
