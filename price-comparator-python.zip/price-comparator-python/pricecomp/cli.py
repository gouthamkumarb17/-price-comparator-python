"""Menu-driven terminal interface. Input and output are injectable so the whole flow is testable."""
from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Callable

from .analysis import Comparison, compare_products, find_outliers, search_records, sort_records, summarize
from .csv_io import parse_csv
from .formatting import format_inr, render_table
from .models import CATEGORIES
from .reports import to_csv, to_markdown, to_text_log
from .seed import sample_records
from .storage import PriceStore
from .validation import parse_category, parse_date, parse_price, parse_product, parse_store

PAGE_SIZE = 10
MENU = (
    ("1", "Add a price"),
    ("2", "Compare products"),
    ("3", "Search records"),
    ("4", "Summary and warnings"),
    ("5", "Import prices from CSV"),
    ("6", "Export a report"),
    ("7", "Load sample data"),
    ("0", "Exit"),
)
_CODES = {"green": "32", "red": "31", "yellow": "33", "bold": "1", "dim": "2"}


class _Cancel(Exception):
    """Raised when the user types 'cancel' at any prompt."""


def _category_choice(raw: str) -> str:
    text = raw.strip()
    if text.isdigit():
        number = int(text)
        if 1 <= number <= len(CATEGORIES):
            return CATEGORIES[number - 1]
        raise ValueError(f"Choose a number from 1 to {len(CATEGORIES)}.")
    return parse_category(raw)


def _nonblank(raw: str) -> str:
    if not raw.strip():
        raise ValueError("This cannot be blank.")
    return raw.strip()


def _export_format(raw: str) -> str:
    choice = raw.strip().lower()
    if choice not in ("csv", "md", "txt"):
        raise ValueError("Type csv, md or txt.")
    return choice


class CliApp:
    def __init__(
        self,
        store: PriceStore,
        input_fn: Callable[[str], str] = input,
        output: Callable[[str], None] = print,
        today: date | None = None,
        color: bool = False,
        export_dir: str | Path = "exports",
    ):
        self.store = store
        self.input_fn = input_fn
        self.output = output
        self.today = today or date.today()
        self.color = color
        self.export_dir = Path(export_dir)

    # ---- small helpers -------------------------------------------------
    def say(self, text: str = "") -> None:
        self.output(text)

    def paint(self, text: str, style: str) -> str:
        return f"\033[{_CODES[style]}m{text}\033[0m" if self.color else text

    def ask(self, prompt: str, parse: Callable[[str], object], default=None):
        """Keep asking until `parse` accepts the answer. A blank answer returns `default` when one is given."""
        while True:
            raw = self.input_fn(prompt)
            if raw.strip().lower() == "cancel":
                raise _Cancel
            if default is not None and not raw.strip():
                return default
            try:
                return parse(raw)
            except ValueError as exc:
                self.say(self.paint(f"  ! {exc}", "red"))

    # ---- main loop -----------------------------------------------------
    def run(self) -> None:
        self.say(self.paint("+" + "-" * 44 + "+", "bold"))
        self.say(self.paint("|   PRODUCT PRICE COMPARATOR                 |", "bold"))
        self.say(self.paint("|   Find the cheapest store, every time.     |", "bold"))
        self.say(self.paint("+" + "-" * 44 + "+", "bold"))
        for notice in self.store.notices:
            self.say(self.paint(f"Note: {notice}", "yellow"))
        actions = {
            "1": self.add_price,
            "2": self.compare,
            "3": self.search,
            "4": self.summary,
            "5": self.import_csv,
            "6": self.export,
            "7": self.load_sample,
        }
        while True:
            self.say()
            for key, label in MENU:
                self.say(f"  {key}. {label}")
            try:
                choice = self.input_fn("Choose an option: ").strip()
                if choice == "0":
                    break
                action = actions.get(choice)
                if action is None:
                    self.say(self.paint(f"  ! '{choice}' is not a valid option. Type a number from the menu.", "red"))
                    continue
                action()
            except _Cancel:
                self.say("Cancelled.")
            except (EOFError, KeyboardInterrupt):
                self.say()
                break
        self.say("Goodbye. Your records are saved.")

    # ---- actions -------------------------------------------------------
    def add_price(self) -> None:
        self.say(self.paint("Add a price (type 'cancel' at any prompt to go back)", "bold"))
        product = self.ask("Product name: ", parse_product)
        for number, name in enumerate(CATEGORIES, start=1):
            self.say(f"  {number}. {name}")
        category = self.ask("Category (number or name): ", _category_choice)
        shop = self.ask("Store: ", parse_store)
        price = self.ask("Price in rupees: ", parse_price)
        seen = self.ask(f"Date seen [{self.today.isoformat()}]: ", lambda r: parse_date(r, self.today), default=self.today.isoformat())
        record = self.store.add(
            {"product": product, "category": category, "store": shop, "price": price, "date": seen}, today=self.today
        )
        self.say(self.paint(f"Saved: {record.product} at {record.store} for {format_inr(record.price)}.", "green"))
        comparison = next((c for c in compare_products(self.store.records) if c.product_key == record.product_key), None)
        if comparison and comparison.has_choice:
            self.say(f"Cheapest now: {comparison.cheapest_store} at {format_inr(comparison.lowest.price)}.")

    def _comparison_text(self, c: Comparison) -> str:
        rows = []
        for index, offer in enumerate(c.offers):
            lowest = index == 0 and c.has_choice
            note = "lowest" if lowest else (f"+{format_inr(c.gap(offer))} (+{c.gap_pct(offer):.1f}%)" if c.has_choice else "")
            rows.append((("> " if lowest else "  ") + offer.store, format_inr(offer.price), note, offer.date))
        title = self.paint(f"{c.product} ({c.category})", "bold")
        table = render_table(("Store", "Price", "Vs lowest", "Seen"), rows, "lrll")
        if c.has_choice:
            saving = self.paint(f"Save {format_inr(c.savings)} ({c.savings_pct:.1f}%) by buying at {c.cheapest_store}.", "green")
        else:
            saving = "Only one store so far. Add another price to compare."
        return f"{title}\n{table}\n{saving}"

    def compare(self) -> None:
        needle = self.ask("Product to show (Enter for all): ", lambda r: r.strip().casefold(), default="")
        shown = [c for c in compare_products(self.store.records) if needle in c.product_key]
        if not shown:
            self.say("No products match. Add a price first with option 1.")
            return
        for c in shown:
            self.say()
            self.say(self._comparison_text(c))

    def search(self) -> None:
        query = self.ask("Keyword (Enter for any): ", lambda r: r.strip(), default="")
        chosen = self.ask("Category number or name (Enter for any): ", _category_choice, default="")
        results = sort_records(search_records(self.store.records, query, chosen or None), "date")
        if not results:
            self.say("No records match. Try a shorter keyword or a different category.")
            return
        flagged = find_outliers(self.store.records)
        for start in range(0, len(results), PAGE_SIZE):
            page = results[start : start + PAGE_SIZE]
            rows = [
                (r.id, r.product, r.category, r.store, format_inr(r.price), r.date, "CHECK PRICE" if r.id in flagged else "")
                for r in page
            ]
            self.say(render_table(("ID", "Product", "Category", "Store", "Price", "Date", "Flag"), rows, "rllllll"))
            self.say(self.paint(f"Showing {start + 1}-{start + len(page)} of {len(results)}", "dim"))
            if start + PAGE_SIZE < len(results) and self.input_fn("Enter for next page, q to stop: ").strip().lower() == "q":
                break

    def summary(self) -> None:
        s = summarize(self.store.records, self.today)
        if not s.record_count:
            self.say("No records yet.")
            return
        self.say(self.paint("Summary", "bold"))
        self.say(f"  Records: {s.record_count}   Products: {s.product_count}   Stores: {s.store_count}")
        self.say(f"  Average price: {format_inr(s.average_price)}   Average saving: {s.average_saving_pct:.1f}%")
        self.say(f"  Best store overall: {s.best_store or 'not enough data'}")
        if s.store_wins:
            self.say("  Cheapest-price wins: " + ", ".join(f"{k} {v}" for k, v in sorted(s.store_wins.items(), key=lambda kv: -kv[1])))
        rows = []
        for c in s.comparisons:
            prices = [o.price for o in c.offers]
            trend = s.trends.get(c.product)
            rows.append((
                c.product,
                c.cheapest_store if c.has_choice else "-",
                format_inr(min(prices)),
                format_inr(max(prices)),
                format_inr(sum(prices) / len(prices)),
                "-" if trend is None else f"{'up' if trend > 0 else 'down' if trend < 0 else 'flat'} {abs(trend):.1f}%",
            ))
        self.say()
        self.say(render_table(("Product", "Cheapest", "Lowest", "Highest", "Average", "Trend"), rows, "lllrrl"))
        by_id = {r.id: r for r in s.records}
        self.say()
        if not s.outliers and not s.stale:
            self.say(self.paint("No warnings.", "green"))
        for record_id, why in s.outliers.items():
            r = by_id[record_id]
            self.say(self.paint(f"WARNING  {r.product} at {r.store} is {format_inr(r.price)} on {r.date}. {why}.", "yellow"))
        for r in s.stale:
            self.say(self.paint(f"WARNING  {r.product} at {r.store} has not been updated since {r.date}.", "yellow"))

    def import_csv(self) -> None:
        path = Path(self.ask("Path to CSV file: ", _nonblank)).expanduser()
        try:
            text = path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeDecodeError) as exc:
            self.say(self.paint(f"  ! Could not read {path}: {exc}", "red"))
            return
        result = parse_csv(text, self.today, existing=self.store.records)
        self.store.add_records(result.records)
        self.say(self.paint(result.describe(), "green" if not result.errors else "yellow"))
        for error in result.errors[:20]:
            self.say(f"  row {error.row}: {error.message}")
        if len(result.errors) > 20:
            self.say(f"  ...and {len(result.errors) - 20} more.")

    def export(self) -> None:
        kind = self.ask("Format - csv, md or txt [csv]: ", _export_format, default="csv")
        records = self.store.records
        if kind == "csv":
            text = to_csv(records)
        elif kind == "md":
            text = to_markdown(summarize(records, self.today), self.today)
        else:
            text = to_text_log(records, find_outliers(records), self.today)
        target = self.export_dir / f"price_report_{self.today.isoformat()}.{kind}"
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text, encoding="utf-8")
        except OSError as exc:
            self.say(self.paint(f"  ! Could not write {target}: {exc}", "red"))
            return
        self.say(self.paint(f"Report written to {target}", "green"))

    def load_sample(self) -> None:
        answer = self.ask("This replaces all current records. Type yes to continue [no]: ", lambda r: r.strip().lower(), default="no")
        if answer == "yes":
            self.store.replace_all(sample_records(self.today))
            self.say(self.paint("Sample data loaded.", "green"))
        else:
            self.say("Nothing changed.")
