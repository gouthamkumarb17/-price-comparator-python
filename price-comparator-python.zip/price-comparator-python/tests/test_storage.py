import json
import tempfile
import unittest
from datetime import date
from pathlib import Path

from pricecomp.seed import sample_records
from pricecomp.storage import PriceStore
from pricecomp.validation import ValidationError

TODAY = date(2026, 11, 24)
GOOD = {"product": "Green Tea", "category": "Groceries", "store": "Metro Mart", "price": "185", "date": "2026-11-20"}


class StoreTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "data" / "prices.json"

    def test_missing_file_is_created_with_sample_data(self):
        store = PriceStore(self.path, today=TODAY)
        self.assertEqual(len(store.records), 38)
        self.assertTrue(self.path.exists())
        self.assertTrue(store.notices)

    def test_can_start_empty(self):
        self.assertEqual(PriceStore(self.path, seed_if_missing=False, today=TODAY).records, [])

    def test_data_survives_restart(self):
        first = PriceStore(self.path, seed_if_missing=False, today=TODAY)
        added = first.add(GOOD)
        second = PriceStore(self.path, today=TODAY)
        self.assertEqual(second.records, [added])
        self.assertEqual(second.notices, [])

    def test_rejects_invalid_record_and_changes_nothing(self):
        store = PriceStore(self.path, seed_if_missing=False, today=TODAY)
        with self.assertRaises(ValidationError) as ctx:
            store.add({**GOOD, "price": "free", "store": ""})
        self.assertEqual(set(ctx.exception.errors), {"price", "store"})
        self.assertEqual(store.records, [])

    def test_ids_increase_and_are_not_reused_in_a_session(self):
        store = PriceStore(self.path, seed_if_missing=False, today=TODAY)
        a, b = store.add(GOOD), store.add({**GOOD, "store": "Daily Basket"})
        self.assertEqual((a.id, b.id), (1, 2))
        self.assertTrue(store.delete(1))
        self.assertEqual(store.add({**GOOD, "store": "Online Bazaar"}).id, 3)
        self.assertFalse(store.delete(999))

    def test_corrupted_json_is_backed_up_and_replaced(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text("{ this is not json", encoding="utf-8")
        store = PriceStore(self.path, today=TODAY)
        self.assertEqual(store.records, [])
        self.assertTrue((self.path.parent / "prices.corrupt.json").exists())
        self.assertIn("could not be read", store.notices[0])
        self.assertEqual(json.loads(self.path.read_text())["records"], [])

    def test_binary_garbage_is_survivable(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_bytes(b"\xff\xfe\x00\x01garbage")
        self.assertEqual(PriceStore(self.path, today=TODAY).records, [])

    def test_wrong_shape_is_treated_as_corrupt(self):
        self.path.parent.mkdir(parents=True)
        for payload in ('{"records": 5}', '{"nope": []}', '"text"', "42"):
            self.path.write_text(payload, encoding="utf-8")
            self.assertEqual(PriceStore(self.path, today=TODAY).records, [], payload)

    def test_invalid_items_are_skipped_not_fatal(self):
        good = sample_records(TODAY)[0].to_dict()
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps({"records": [good, {"product": "x"}, "junk", {**good, "price": -1}]}), encoding="utf-8")
        store = PriceStore(self.path, today=TODAY)
        self.assertEqual(len(store.records), 1)
        self.assertIn("3 invalid", store.notices[0])

    def test_duplicate_or_missing_ids_are_repaired(self):
        a = sample_records(TODAY)[0].to_dict()
        b = {**sample_records(TODAY)[1].to_dict(), "id": a["id"]}
        c = {k: v for k, v in sample_records(TODAY)[2].to_dict().items() if k != "id"}
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps([a, b, c]), encoding="utf-8")
        ids = [r.id for r in PriceStore(self.path, today=TODAY).records]
        self.assertEqual(len(set(ids)), 3)
        self.assertTrue(all(i > 0 for i in ids))

    def test_no_temp_files_left_behind(self):
        store = PriceStore(self.path, seed_if_missing=False, today=TODAY)
        store.add(GOOD)
        self.assertEqual([p.name for p in self.path.parent.iterdir()], ["prices.json"])

    def test_replace_all_and_add_records(self):
        store = PriceStore(self.path, today=TODAY)
        store.replace_all(sample_records(TODAY)[:3])
        self.assertEqual(len(store.records), 3)
        store.add_records(sample_records(TODAY)[3:5])
        self.assertEqual(sorted(r.id for r in store.records), [1, 2, 3, 4, 5])
        self.assertEqual(len(PriceStore(self.path, today=TODAY).records), 5)


if __name__ == "__main__":
    unittest.main()
