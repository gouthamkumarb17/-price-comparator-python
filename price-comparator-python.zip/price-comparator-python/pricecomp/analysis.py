"""Business logic: compare prices, find outliers, summarise. Pure functions, no I/O."""
from __future__ import annotations

import statistics
from dataclasses import dataclass
from datetime import date
from typing import Iterable, Sequence

from .formatting import format_inr
from .models import PriceRecord


@dataclass(frozen=True)
class Comparison:
    """All current store prices for one product, cheapest first."""

    product: str
    category: str
    offers: tuple[PriceRecord, ...]

    @property
    def product_key(self) -> str:
        return self.product.casefold()

    @property
    def has_choice(self) -> bool:
        return len(self.offers) > 1

    @property
    def lowest(self) -> PriceRecord:
        return self.offers[0]

    @property
    def highest(self) -> PriceRecord:
        return self.offers[-1]

    @property
    def cheapest_store(self) -> str:
        return self.lowest.store

    @property
    def savings(self) -> float:
        return round(self.highest.price - self.lowest.price, 2)

    @property
    def savings_pct(self) -> float:
        return self.savings / self.highest.price * 100 if self.highest.price else 0.0

    def gap(self, offer: PriceRecord) -> float:
        return round(offer.price - self.lowest.price, 2)

    def gap_pct(self, offer: PriceRecord) -> float:
        return self.gap(offer) / self.lowest.price * 100 if self.lowest.price else 0.0


@dataclass(frozen=True)
class Summary:
    records: tuple[PriceRecord, ...]
    record_count: int
    product_count: int
    store_count: int
    average_price: float
    average_saving_pct: float
    store_wins: dict[str, int]
    best_store: str | None
    comparisons: tuple[Comparison, ...]
    trends: dict[str, float]  # product name -> average % change
    outliers: dict[int, str]  # record id -> reason
    stale: tuple[PriceRecord, ...]


def latest_prices(records: Iterable[PriceRecord]) -> list[PriceRecord]:
    """The newest record for every product + store pair (ties on date go to the higher id)."""
    newest: dict[tuple[str, str], PriceRecord] = {}
    for r in records:
        key = (r.product_key, r.store_key)
        current = newest.get(key)
        if current is None or (r.date, r.id) > (current.date, current.id):
            newest[key] = r
    return list(newest.values())


def compare_products(records: Iterable[PriceRecord], exclude_ids: Iterable[int] = ()) -> list[Comparison]:
    skip = set(exclude_ids)
    groups: dict[str, list[PriceRecord]] = {}
    for r in latest_prices(r for r in records if r.id not in skip):
        groups.setdefault(r.product_key, []).append(r)
    result = []
    for offers in groups.values():
        offers.sort(key=lambda r: (r.price, r.store_key))
        newest = max(offers, key=lambda r: (r.date, r.id))
        result.append(Comparison(newest.product, newest.category, tuple(offers)))
    return sorted(result, key=lambda c: c.product_key)


def find_outliers(records: Sequence[PriceRecord], factor: float = 2.0, min_samples: int = 4) -> dict[int, str]:
    """Flag prices more than `factor` times above or below the product's median price."""
    groups: dict[str, list[PriceRecord]] = {}
    for r in records:
        groups.setdefault(r.product_key, []).append(r)
    flagged: dict[int, str] = {}
    for group in groups.values():
        if len(group) < min_samples:
            continue
        median = statistics.median(r.price for r in group)
        for r in group:
            if r.price > median * factor or r.price < median / factor:
                flagged[r.id] = f"Unusual price: far from the typical {format_inr(median)}"
    return flagged


def find_stale(records: Iterable[PriceRecord], today: date | None = None, max_age_days: int = 45) -> list[PriceRecord]:
    today = today or date.today()
    return [r for r in latest_prices(records) if (today - date.fromisoformat(r.date)).days > max_age_days]


def price_trends(records: Iterable[PriceRecord], exclude_ids: Iterable[int] = ()) -> dict[str, float]:
    """Average % change between each store's first and latest price, keyed by product_key."""
    skip = set(exclude_ids)
    series: dict[tuple[str, str], list[PriceRecord]] = {}
    for r in records:
        if r.id not in skip:
            series.setdefault((r.product_key, r.store_key), []).append(r)
    changes: dict[str, list[float]] = {}
    for (product, _store), rows in series.items():
        if len(rows) < 2:
            continue
        rows.sort(key=lambda r: (r.date, r.id))
        first, last = rows[0].price, rows[-1].price
        changes.setdefault(product, []).append((last - first) / first * 100)
    return {p: sum(v) / len(v) for p, v in changes.items()}


def search_records(records: Iterable[PriceRecord], query: str = "", category: str | None = None) -> list[PriceRecord]:
    needle = query.strip().casefold()
    wanted = category.casefold() if category else None
    return [
        r
        for r in records
        if (wanted is None or r.category.casefold() == wanted)
        and (not needle or needle in f"{r.product} {r.store} {r.category}".casefold())
    ]


def sort_records(records: Iterable[PriceRecord], key: str = "date") -> list[PriceRecord]:
    rows = list(records)
    if key == "date":
        return sorted(rows, key=lambda r: (r.date, r.id), reverse=True)
    if key == "price":
        return sorted(rows, key=lambda r: (r.price, r.id))
    if key == "product":
        return sorted(rows, key=lambda r: (r.product_key, r.id))
    if key == "store":
        return sorted(rows, key=lambda r: (r.store_key, r.id))
    raise ValueError(f"Unknown sort key: {key}")


def summarize(records: Sequence[PriceRecord], today: date | None = None) -> Summary:
    records = tuple(records)
    outliers = find_outliers(records)
    comparisons = tuple(compare_products(records))
    wins: dict[str, int] = {}
    savings = []
    for c in comparisons:
        if not c.has_choice:
            continue
        savings.append(c.savings_pct)
        for offer in c.offers:
            if offer.price == c.lowest.price:
                wins[offer.store] = wins.get(offer.store, 0) + 1
    best = None
    if wins:
        best = sorted(wins.items(), key=lambda kv: (-kv[1], kv[0].casefold()))[0][0]
    trend_by_key = price_trends(records, exclude_ids=outliers)
    return Summary(
        records=records,
        record_count=len(records),
        product_count=len({r.product_key for r in records}),
        store_count=len({r.store_key for r in records}),
        average_price=(sum(r.price for r in records) / len(records)) if records else 0.0,
        average_saving_pct=(sum(savings) / len(savings)) if savings else 0.0,
        store_wins=wins,
        best_store=best,
        comparisons=comparisons,
        trends={c.product: trend_by_key[c.product_key] for c in comparisons if c.product_key in trend_by_key},
        outliers=outliers,
        stale=tuple(find_stale(records, today)),
    )
